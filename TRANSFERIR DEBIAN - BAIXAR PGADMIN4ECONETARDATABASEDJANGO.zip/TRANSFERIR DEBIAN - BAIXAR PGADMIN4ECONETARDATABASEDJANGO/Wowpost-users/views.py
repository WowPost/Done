from django.shortcuts import render
#from .models import User

def home(request):
    return render(request, 'Users/home.html')

#def User(request):
    #pass